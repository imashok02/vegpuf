import 'package:flutter/cupertino.dart';

class UserIntentHolder {
  const UserIntentHolder({
    @required this.userId,
    @required this.userName,
   
  });
  final String userId;
  final String userName;
  
}
